/*
 * Student Management System
 * Author: Wesley Attram
 */

import java.util.ArrayList;

class Student {
    private String name;
    private int id;
    private double gpa;

    public Student(int id, String name, double gpa) {
        this.id = id;
        this.name = name;
        this.gpa = gpa;
    }

    public void displayStudent() {
        System.out.println("ID: " + id + " | Name: " + name + " | GPA: " + gpa);
    }
}

public class StudentManagement {
    public static void main(String[] args) {
        ArrayList<Student> students = new ArrayList<>();
        students.add(new Student(1, "Alice", 3.8));
        students.add(new Student(2, "Bob", 3.5));

        System.out.println("Student Records:");
        for (Student student : students) {
            student.displayStudent();
        }
    }
}
